package grails_onlycontroller



import spock.lang.*

/**
 *
 */
class User2IntegrationTestSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
