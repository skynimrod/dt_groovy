import grails.util.GrailsUtil

import grails_onlycontroller.User2

class BootStrap {

    def init = { servletContext ->
        switch( GrailsUtil.environment ) {
            case "development":
                def admin = new User2(homepage:"test2",userId:"adams", userName:"Happy new year!").save()
                break;
            case "production":
                break;
        }
    }
    def destroy = {
    }
}
