package grails_onlycontroller

class User2Controller {

    def scaffold = User2
    
    def index() { 
    
        println "i am in index() of User2Controller"
        def user2 = new User2(homepage:"1111",userId:"ux",userName:"hello")
        user2.save()
        println "end of index() of User2Controller"
        
        flash.message = "Hello this is a memeory story!"
        
        def map2=[1:"stockCocde", 2:"url",3:"reportName", 4:"reportType", 5:"createDate", 6:"releaseDate"]
        println map2.getAt(1)
        println map2[2]
        
        def str = "Hello 时间在变化"
        // 获取子串的测试
        def str2 = str.substring(7,9)
        println "str 的7，8位:" + str2     // 汉字也算一个字符
        
        def content = 'var szzbAffiches=[["000707","finalpage/2014-09-12/1200226442.PDF","双环科技：关于召开公司2014年第四次临时股东大会的提示性公告","PDF","250","2014-09-12","2014-09-12 00:00"],["000402","finalpage/2014-09-12/1200226440.PDF","金 融 街：关于回购股份事项中前十名股东持股信息的公告","PDF","88","2014-09-12","2014-09-12 00:00"]]'
        for ( def i = 0; i < content.length(); i ++ ) {
            if ( content[i] == '[') {
                println "Yes , i find ["
                println content.substring(i,content.length())
                println content[0] + content[1] + content[2]
                break
            }
        }


    }
    
    
}
