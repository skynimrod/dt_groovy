package grails_onlycontroller
import grails_onlycontroller.User2
import grails_onlycontroller.ReportList
import www.aqugen.com.FirstService

class FirstController {
    FirstService firstService
    ReportList  reportList

    
    def index() { 
        log.error('hello , this is just a test!')
        println 'id=' + request.getParameter('id')
        println 'actionname is ' + actionName
        //println 'id=' + param.id
        
        reportList = new ReportList(report_name:"name1",report_url:"news.sina.com.cn")
        reportList.save()
        
        //def firstService
        //firstService.helloworld()
        //firstService.downloads("i'a param1","i'am param21")
        def filename = "f:/2015.01.27.txt"
        firstService.download2("http://www.cninfo.com.cn/disclosure/fulltext/plate/szselatest_24h.js", "f:/2015.01.27.txt",1)   
                // 对于此类文件， 必须用单线程下载，否则下载内容会出问题
                
        firstService.processReportList( filename,flash )      // 调用Service 里面涉及GORM的方法
        
//        flash.message("Hello, hello")

        def uu = new User2(userId:"u1",userName:"fromCtrl",homepage:"www.test")
        uu.save()
        
      //redirect(url:'http://news.sina.com.cn')
      //redirect(url:'http://localhost:8080/Grails_OnlyController/view/test2')
      //redirect(view:'/first/test2')
      //redirect(controller:"Adams",action:'index',params:['author':"simon"])
      //redirect(view:'/adams/test3')
      //redirect(action:'test2')
      //redirect(view:'/')
      //render(view:"/adams/test3.gsp")
      //redirect(action:'downloads')
      println '重定向前'
      redirect(uri:'file://e:/readme.txt')
      println '重定向后'
    }
    
    def test2 = { }
    
    def hello = {render 'Hello, just a test!'}
    
    def downloads() {
        println "Hello, u r in downloads() begin"
        //def date="2014-08-22"
        def file = request.getFile('http://www.cninfo.com.cn/disclosure/fulltext/plate/szselatest_24h.js')
        file.transferTo(new java.io.File("/${file.name}"))
        println "Hello, u r in downloads() End ${file.name}"
        

    }

    
    //def scaffold = ReportList
    
    
}
