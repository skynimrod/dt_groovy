package grails_onlycontroller

class AdamsController {

    def index() {
        println 'a greeting message form adams!'
        println 'author is ' + request.getParameter('author')
        println '另一种获取参数的方式， author=' + params?.author

    }
}
