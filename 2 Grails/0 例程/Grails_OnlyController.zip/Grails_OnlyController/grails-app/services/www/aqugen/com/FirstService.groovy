package www.aqugen.com
import grails_onlycontroller.User2

import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.ProtocolException
import java.net.URI
import java.net.URL
import java.util.Random


import grails.transaction.Transactional

// 导入 java 中关于下载功能需要的jar 包


@Transactional
class FirstService {
    
    boolean transactional = false

    def serviceMethod() {

    }
    
    def helloworld() {
        println 'Hello world from firtservice'
        def file = new File("e:/test.txt")
        file.write('Hello worlds')
        
        // 线程测试
        URL url = new URL( "http://news.sina.com.cn" )

        for ( def i=0;i<3;i++) {
            //Thread.start(closure1(i,i+3))
            println "i=${i},i+3=${i+3}"
            startThread( i, i+3)
        }
    }
    
    // 定义一个方法来启动线程， 同时解决参数传递的问题。
    def startThread( p1, p2) {
        Thread.start { 
                def param1 = p1
                def param2 = p2
                        println "Inner thread: "+Thread.currentThread().getName() + ":${param1},${param2}"
                "How are you?".each { a->
                    print a
                }
                sleep 300
                println "end of  thread: "+Thread.currentThread().getName() + ":${param1},${param2}"
            }
            //sleep 2
    }
    
    def downloads( param1, param2) {
        println "Hello, u r in downloads() begin"
        //def date="2014-08-22"
        //def file = request.getFile('http://www.cninfo.com.cn/disclosure/fulltext/plate/szselatest_24h.js')
        //file.transferTo(new java.io.File("/${file.name}"))
       // println "Hello, u r in downloads() End ${file.name}"
        
        println "Hello, param1->" + param1
        println "Hello, param2->" + param2
              println '重定向前 from downloads()'
      redirect(uri:'file://e:/readme.txt')
      println '重定向后 from downloads()s'
    }
    
    /**
     * 参数说明:
     *       urlPath :  要下载的目标数据的url 字符串
     *       destfile : 下载后的内容要保存的目标文件名称， 包含路径
     *       threadnum: 要启动的同时进行下载功能的线程数量， 对于大文件， 可以加速下载速度
     */
    def download2( urlPath, destfile, threadnum ) //throws Exception//下载的方法
    {//参数 下载地址，线程数量
        
        URL url = new URL( urlPath )
        HttpURLConnection conn  = (HttpURLConnection)url.openConnection()//获取HttpURLConnection对象
        
        conn.setRequestMethod( "GET" )//设置请求格式，这里是GET格式
        conn.setReadTimeout( 5*1000 )//
        
        def filelength = conn.getContentLength()//获取要下载文件的长度
        
        conn.disconnect()
        
        println "要下载的文件大小为"+filelength
        //def filelength = 2000
        //def filename = getFilename(path)
       
        File saveFile = new File(destfile)
    
        if (saveFile.exists() ) saveFile.delete()      // 如果文件存在， 先删除
        
        RandomAccessFile accessFile = new RandomAccessFile(saveFile, "rwd")
        accessFile.setLength(filelength)
        accessFile.close()
        
    
        int block = filelength%threadnum ==0?filelength/threadnum:filelength/threadnum+1
     
        println "block = $block"
        
        for(int i = 0; i < threadnum; i ++ ){
            def start = i * block
            def end = ( i + 1 ) * block -1
            
            if ( end > filelength ) end = filelength           // 防止超出范围, 虽然大部分情况超出也没有问题
            //Thread.start( downloadThread.call(urlPath, destfile, start, end ) )
            //if ( i != 1 ) continue
            downloadThread( urlPath, destfile, start, end, filelength )                              
            //new DownloadThread(url,saveFile,block,threadid).start();
        }
        
                                        
    }
    
    def downloadThread( urlPath, saveFile, startpos, endpos, filelength ) {
        // 需要注意的是上面的参数都是应该是Java 中对应的类型
        Thread.start{
            def start = startpos
            def end = endpos
            println "开始进行下载了， 大家注意了"

            def threadName = Thread.currentThread().getName()
            println "$threadName : url=$urlPath, saveFile=$saveFile, start=$start, end=$end"

            RandomAccessFile accessFile = new RandomAccessFile(saveFile, "rwd");
            accessFile.seek( start );//设置从什么位置写入数据
            
            URL url = new URL( urlPath )
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setReadTimeout(5*1000);
            conn.setRequestProperty("Range","bytes="+start+"-"+end);
            println "下载范围为:" + conn.getRequestProperty("Range")
            InputStream inStream = conn.getInputStream();
            byte[] buffer = new byte[1024];
            int len = 0; 
            int total = 0
            while((len = inStream.read(buffer))!=-1){
                if ( (total + len) > (end-start)) {
                    // 如果超出范围， 则只下载范围内的部分， 然后退出循环
                    accessFile.write( buffer, 0, end - start - total)
                    break
                }else {
                    accessFile.write(buffer, 0, len);
                }
                if (len < 1024) println threadName + ":小于1024的为" + len
                total += len
            }
            
            println "总下载长度为:" + total
            inStream.close();
            accessFile.close();
            conn.disconnect()
            println("线程id："+threadName +"下载完成");

        }
    }
    
    // 处理深圳A股公告
    // 设计 GORM 对象 来存放公告名称， 下载地址，公告日期, A股代码等等
    def procSZReportList(  srcFile ) {
        
        // 0. 容错处理， 判读源文件是否存在， 是否合法之类的
        
        // 1. 获取 文件类的原始公告字符串
        def content = new File( srcFile ).text
        
        // 2. 处理 原始公告， 解析后存放在 一个hash 表中
        def map =[:]       // "stockCode",  "url", "reportName", "Type", "CreateDate", "ReleaseDate"
        def map2=[1:"stockCocde", 2:"url",3:"reportName", 4:"reportType", 5:"createDate", 6:"releaseDate"]
        
        // 遍历深证公告的算法参见 2014.09.17 
        for ( i in 0..content.length()-1 ) {
            if ( content[i] == '[' && i < content.length()-1 && content[i+1] =='"' ) {
               // 只有当前字符是'[', 并且下一个字符是双引号, 才开始一个公告的信息 
               i ++       // 跳过 ‘['
               def j = 1       // 这儿的 j 就是为了标志item 名称的，对应 map2
               for ( ; i<content.length()-1; i ++ ) {    // 这个循环正好处理一条公告内容
                   // 跳出循环的判断, 碰到右方括号, 并且后面是另一个右方括号(结束), 或者逗号(公告之间的分隔符)
                   if ( content[i] == ']' || content[i] ==',' ) {
                       break;    // 表示这条公告处理结束, 继续处理下一个公告
                   }
                   
                    def itemFlag = false   
                    // 这个标志是用来表示一个Item 是否已经处理完成, 用来辅助处理,
                    // 主要是为了容错， 有些公告内容也包含方括号，逗号等
                   if ( content[i] == '"' ) {   // 开始处理一个item
                       def k = i + 1       // 记录item 的开始位置, +1 是为了跳过双引号
                       while ( !itemFlag && i < content.length() -1 ) {   // 这个循环是处理一个item. 处理完成后, itemFlag 会被设为true
                           if ( content[i] =='"' && content[i+1] == ',' ) {  判断item 结束
                               // 处理公告记录中的一项的结束, 双引号中的内容， 这儿做了容错处理, 有些公告内容也包含双引号，逗号之类的
                               itemFlag = true
                               // 保存 k - i 之间的字符串, 这就是一个item 的内容
                               //map[ map2.getAt(j) ] = content.substr(k,i)
                               j ++
                           }
                       }
                   }
               }
            }
            
        }

        
    }
    
    // 处理公告列表文件
    // 使用 GORM 对象， 将数据存储在DB中， 输出内容 通过 动态创建gsp 来显示。
    def processReportList( srcFile, flash  ) {
        
        println "FirstService.processReportList()"
        def u = new User2( userId:"user1",userName:"Adams", homepage:"http://news.sina.com.cn")
        
        u.save();
        println "FirstService.processReportList()  end "
        
        // 上面是测试GORM 。 下面来进行文件访问操作
        def content = new File( srcFile ).text
        flash.message = content
        
        // ["000707","finalpage/2014-09-12/1200226442.PDF",
        // "双环科技：关于召开公司2014年第四次临时股东大会的提示性公告",
        // "PDF","250","2014-09-12","2014-09-12 00:00"]
        content = 'var szzbAffiches=[["000707","finalpage/2014-09-12/1200226442.PDF","双环科技：关于召开公司2014年第四次临时股东大会的提示性公告","PDF","250","2014-09-12","2014-09-12 00:00"],["000402","finalpage/2014-09-12/1200226440.PDF","金 融 街：关于回购股份事项中前十名股东持股信息的公告","PDF","88","2014-09-12","2014-09-12 00:00"]]'
//        content = 'var szzbAffiches=["000707","finalpage/2014-09-12/1200226442.PDF","双环科技：关于召开公司2014年第四次临时股东大会的提示性公告","PDF","250","2014-09-12","2014-09-12 00:00"]'
        //content = '["000707","finalpage/2014-09-12/1200226442.PDF"'
        def  matcher = ( content =~ /(\[{1}\"{1}.{6}\"{1},\"{1}.*\"{1},\"{1}.*\"{1},\"{1}.*\"{1},\"{1}.*\"{1},\"{1}.*\"{1},\"{1}.*\"{1}\]{1})/ )
        //def matcher = content=~ /[\"[0-9]/
        //for ( def i = 0; i <matcher.size(), i ++  )
        println matcher.getCount()
        
        for ( def i = 0; i < matcher.getCount(); i ++ )
                    println matcher[i][0]
                    
        def saying = """Now is the time for all good men (and women) to come to the aid
of their country"""
def pattern = ~/(\w+en)/
//def matcher1 = pattern.matcher(saying)
//def matcher1 = saying =~ pattern
def matcher1 = saying =~ /(\w+en)/
def count = matcher1.getCount()
println "Matches = ${count}"
for(i in 0..<count) {
    println matcher1[i]
}
        
           /*
        def matcher = ( "finda" =~ /find/ )
        //assert "find" == matcher[0]
        println matcher.getCount()
        println matcher[0]
        */
    }
}