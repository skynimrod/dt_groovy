package grails_onlycontroller

class User2 {

    String userId
    String userName
    String homepage
    /*
    static constraints = {
    }
    */
}
