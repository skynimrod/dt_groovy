package grails_onlycontroller

class ReportList {
 // "stockCode",  "url", "reportName", "Type", "CreateDate", "ReleaseDate"
    static constraints = {
    }
    String stockCode
    String reportName
    String reprotType
    String reportUrl
    String createDate
    String releaseDate
    
}
