package org.grails.samples

/**
 * Models a {@link Vet Vet's} specialty (for example, dentistry).
 *
 * @author Graeme Rocher
 */
class Speciality {
	String name
}
