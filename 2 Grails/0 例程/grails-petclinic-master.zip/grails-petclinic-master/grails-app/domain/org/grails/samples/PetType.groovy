package org.grails.samples

/**
 * @author Graeme Rocher
 */
class PetType {
	String name
}
